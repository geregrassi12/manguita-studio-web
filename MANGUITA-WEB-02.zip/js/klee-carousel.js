// document.addEventListener("DOMContentLoaded", function () {
//   const kleeCarousel = document.querySelector(".klee-swiper");

//   if (kleeCarousel) {
//     new Swiper(".klee-swiper", {
//       loop: true,
//       slidesPerView: 1,
//       spaceBetween: 0,
//       autoplay: {
//         delay: 3000,          // 3 segundos
//         disableOnInteraction: false
//       },
//       navigation: {
//         nextEl: ".swiper-button-next",
//         prevEl: ".swiper-button-prev",
//       }
//     });
//   }
// });
